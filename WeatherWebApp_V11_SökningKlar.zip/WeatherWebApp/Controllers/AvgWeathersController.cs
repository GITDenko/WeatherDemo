﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WeatherWebApp.Models;

namespace WeatherWebApp.Controllers
{
    public class AvgWeathersController : Controller
    {
        private readonly WeatherContext _context;

        public AvgWeathersController(WeatherContext context)
        {
            _context = context;
        }

        // GET: AvgWeathers
        public ViewResult Index(string sortOrder, string searchString)
        {
            ViewBag.CurrentSort = sortOrder;
            ViewBag.NameSortParm = String.IsNullOrEmpty(sortOrder) ? "temperatur_inne" : ""; //Medeltemp inne, högst till lägst
            ViewBag.NameSortParm2 = String.IsNullOrEmpty(sortOrder) ? "temperatur_ute" : ""; //Medeltemp ute
            ViewBag.NameSortParm3 = String.IsNullOrEmpty(sortOrder) ? "luftfukt_inne" : ""; //Luftfukt. inne, lägst till högst
            ViewBag.NameSortParm4 = String.IsNullOrEmpty(sortOrder) ? "luftfukt_ute" : "";  //Luftfukt. ute
            ViewBag.NameSortParm5 = String.IsNullOrEmpty(sortOrder) ? "mogelrisk_inne" : ""; //Mögelrisk inne, lägst till högst
            ViewBag.NameSortParm6 = String.IsNullOrEmpty(sortOrder) ? "mogelrisk_ute" : ""; //Mögelrisk ute

            var weather = from w in _context.AvgWeatherTable select w;

            if (!String.IsNullOrEmpty(searchString)) //SÖKFUNKTION
            {
                try
                {
                    DateTime.Parse(searchString);
                    weather = weather.Where(w => w.Datum == DateTime.Parse(searchString));
                }
                catch (FormatException)
                {
                    weather = weather.Where(w => w.Plats == searchString);
                }
            } 

            switch (sortOrder)
            {
                case "temperatur_inne": //Medeltemp inne, högst till lägst
                    weather = weather.Where(x => x.Plats == "Inne").OrderByDescending(w => w.MedelTemp);
                    break;
                case "temperatur_ute": //Medeltemp ute
                    weather = weather.Where(x => x.Plats == "Ute").OrderByDescending(w => w.MedelTemp);
                    break;
                case "luftfukt_inne": //Luftfukt. inne, lägst till högst
                    weather = weather.Where(x => x.Plats == "Inne").OrderBy(w => w.MedelLuftfuktighet);
                    break;
                case "luftfukt_ute": //Luftfukt. ute
                    weather = weather.Where(x => x.Plats == "Ute").OrderBy(w => w.MedelLuftfuktighet);
                    break;
                case "mogelrisk_inne": //Mögelrisk inne, lägst till högst
                    weather = weather.Where(x => x.Plats == "Inne").OrderByDescending(x => x.Mogelrisk == "Ingen risk");
                    break;
                case "mogelrisk_ute": //Mögelrisk ute
                    weather = weather.Where(x => x.Plats == "Ute").OrderByDescending(x => x.Mogelrisk == "Ingen risk");
                    break;
            }

            return View(weather.ToList());
        }

        // GET: AvgWeathers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var avgWeather = await _context.AvgWeatherTable
                .FirstOrDefaultAsync(m => m.Id == id);
            if (avgWeather == null)
            {
                return NotFound();
            }

            return View(avgWeather);
        }

        // GET: AvgWeathers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: AvgWeathers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Datum,Plats,MedelTemp,MedelLuftfuktighet,Mogelrisk")] AvgWeather avgWeather)
        {
            if (ModelState.IsValid)
            {
                _context.Add(avgWeather);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(avgWeather);
        }

        // GET: AvgWeathers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var avgWeather = await _context.AvgWeatherTable.FindAsync(id);
            if (avgWeather == null)
            {
                return NotFound();
            }
            return View(avgWeather);
        }

        // POST: AvgWeathers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Datum,Plats,MedelTemp,MedelLuftfuktighet,Mogelrisk")] AvgWeather avgWeather)
        {
            if (id != avgWeather.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(avgWeather);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AvgWeatherExists(avgWeather.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(avgWeather);
        }

        // GET: AvgWeathers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var avgWeather = await _context.AvgWeatherTable
                .FirstOrDefaultAsync(m => m.Id == id);
            if (avgWeather == null)
            {
                return NotFound();
            }

            return View(avgWeather);
        }

        // POST: AvgWeathers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var avgWeather = await _context.AvgWeatherTable.FindAsync(id);
            _context.AvgWeatherTable.Remove(avgWeather);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AvgWeatherExists(int id)
        {
            return _context.AvgWeatherTable.Any(e => e.Id == id);
        }
    }
}
