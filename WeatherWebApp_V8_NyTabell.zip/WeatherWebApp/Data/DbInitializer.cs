﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WeatherWebApp.Models;

namespace WeatherWebApp.Data
{
    public class DbInitializer
    {
        public static void Initialize(WeatherContext context)
        {
            context.Database.EnsureCreated();

            if (context.WeatherTable.Any())
            {
                return;
            }

            string filePath = @"TempFuktData.csv";

            List<string> lines = File.ReadAllLines(filePath).ToList();

            List<Weather> weatherList = new List<Weather>();

            foreach (string line in lines)
            {
                CultureInfo provider = CultureInfo.InvariantCulture;

                string[] entries = line.Split(',');
                Weather newWeather = new Weather();

                newWeather.Tid = DateTime.Parse(entries[0]); 
                newWeather.Plats = entries[1];
                try
                {
                    newWeather.Temp = decimal.Parse(entries[2], provider);
                    //Console.WriteLine("Converted '{0}' to {1}.", line, newWeather.Temp);
                }
                catch (FormatException)
                {
                    newWeather.Temp = null;
                    //Console.WriteLine("Unable to convert '{0}' to a Decimal.", line);
                }
                catch (OverflowException)
                {
                    newWeather.Temp = null;
                    //Console.WriteLine("'{0}' is outside the range of a Decimal.", line);
                }
                newWeather.Luftfuktighet = int.Parse(entries[3]);
                weatherList.Add(newWeather);
            }

            foreach (var x in weatherList) //Lägger till info i Databasen
            {
                context.WeatherTable.Add(x); //Koppling till DbSet Weather
            }
            context.SaveChanges(); // Sparar

            ////////// Initiliaze new info in "Average Info List" /////////////////
            
            List<AvgWeather> avgWeatherList = new List<AvgWeather>();

            List<decimal?> avgdagtempUte, avgdagtempInne;
            List<int> avgluftUte, avgluftInne;
            

            decimal? dagstempUte, dagstempInne;
            int luftfuktInne = 0, luftfuktUte = 0;
            string mogelriskInne = "", mogelriskUte = "";

            int i=1, j=10;
            for (i = 1; i < 65; i++)
            {
                if (j == 11 && i == 31)
                {
                    break;
                }
                if (j == 10 && i == 32)
                {
                    i = 1; // Första
                    j = 11; // November
                }
                DateTime dag = new DateTime(2016, j, i); // BöRJAN AV MÅNDAG >
                DateTime dag2 = new DateTime(2016, j, i+1); // BÖRJAN AV TISDAG <
                
                //Medeltemperatur Ute
                avgdagtempUte = weatherList.
                     Where(x => x.Tid <= dag && x.Tid >= dag2).
                     Where(x => x.Plats == "Ute").
                     Select(x => x.Temp).ToList();
                dagstempUte = avgdagtempUte.Average();

                //Medeltemperatur Inne
                avgdagtempInne = weatherList.
                    Where(x => x.Tid <= dag && x.Tid >= dag2).
                     Where(x => x.Plats == "Inne").
                     Select(x => x.Temp).ToList();
                dagstempInne = avgdagtempInne.Average();

                //Medelfuktighet Ute
                avgluftUte = weatherList.
                      Where(x => x.Tid <= dag && x.Tid >= dag2).
                      Where(x => x.Plats == "Ute").
                      Select(x => x.Luftfuktighet).ToList();
                luftfuktUte = Convert.ToInt32(avgluftUte.Average());

                //Medelfuktighet Inne
                avgluftInne = weatherList.
                   Where(x => x.Tid <= dag && x.Tid >= dag2).
                   Where(x => x.Plats == "Inne").
                   Select(x => x.Luftfuktighet).ToList();
                luftfuktInne = Convert.ToInt32(avgluftInne.Average());

                //Mögelrisk Inne
                if ((dagstempInne >= 30) && (dagstempInne <= 50) && (luftfuktInne >= 90) && (luftfuktInne <= 100))
                { mogelriskInne = "Hög risk"; }
                if (dagstempInne >= 20 && dagstempInne <= 30 && luftfuktInne >= 80 && luftfuktInne <= 90)
                { mogelriskInne = "Låg risk"; }
                else
                { mogelriskInne = "Ingen risk"; }

                //Mögelrisk Ute
                if ((dagstempUte >= 30) && (dagstempUte <= 50) && (luftfuktUte >= 90) && (luftfuktUte <= 100))
                { mogelriskUte = "Hög risk"; }
                if (dagstempUte >= 20 && dagstempUte <= 30 && luftfuktUte >= 80 && luftfuktUte <= 90)
                { mogelriskUte = "Låg risk"; }
                else
                { mogelriskUte = "Ingen risk"; }


                var medeldagenute = new AvgWeather { Datum = dag, Plats = "Ute", MedelTemp = dagstempUte, MedelLuftfuktighet = luftfuktUte, Mogelrisk = mogelriskUte };
                var medeldageninne = new AvgWeather { Datum = dag, Plats = "Inne", MedelTemp = dagstempInne, MedelLuftfuktighet = luftfuktInne, Mogelrisk = mogelriskInne };

                context.AvgWeatherTable.Add(medeldagenute); //Koppling till DbSet Weather
                context.AvgWeatherTable.Add(medeldageninne); //Koppling till DbSet Weather
            }

            context.SaveChanges();//sparar



        }
    }
}
