﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WeatherWebApp.Models
{
    public class Weather
    {
        public int Id { get; set; }
        public DateTime Tid { get; set; }
        public string Plats { get; set; }
        public decimal? Temp { get; set; }
        public int Luftfuktighet { get; set; }
    }
}