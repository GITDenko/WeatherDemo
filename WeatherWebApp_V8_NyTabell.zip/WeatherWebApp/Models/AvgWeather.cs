﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WeatherWebApp.Models
{
    public class AvgWeather
    {
        public int Id { get; set; }
        public DateTime Datum { get; set; }
        public string Plats { get; set; }
        public decimal? MedelTemp { get; set; }
        public int MedelLuftfuktighet { get; set; }
        public string Mogelrisk { get; set; }
    }
}
