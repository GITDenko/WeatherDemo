﻿SELECT
  DAY(Tid),
  MONTH(Tid),
  AVG(Temp),
  AVG(Luffuktighet)
FROM WeatherTable

WHERE  Tid BETWEEN '2016-10-01' AND '2016-11-30' And Plats ='Ute'
GROUP BY  DAY(Tid), MONTH(Tid) ORDER BY AVG(temp) DESC;