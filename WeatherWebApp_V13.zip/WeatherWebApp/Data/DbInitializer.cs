﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WeatherWebApp.Models;

namespace WeatherWebApp.Data
{
    public class DbInitializer
    {
        public static void Initialize(WeatherContext context)
        {
            context.Database.EnsureCreated();

            if (context.WeatherTable.Any())
            {
                return;
            }

            string filePath = @"TempFuktData.csv";

            List<string> lines = File.ReadAllLines(filePath).Distinct().ToList();

            List<Weather> weatherList = new List<Weather>();

            foreach (string line in lines)
            {
                CultureInfo provider = CultureInfo.InvariantCulture;

                string[] entries = line.Split(',');
                Weather newWeather = new Weather();

                newWeather.Tid = DateTime.Parse(entries[0]); 
                newWeather.Plats = entries[1];
                try
                {
                    newWeather.Temp = decimal.Parse(entries[2], provider);
                    //Console.WriteLine("Converted '{0}' to {1}.", line, newWeather.Temp);
                }
                catch (FormatException)
                {
                    newWeather.Temp = null;
                    //Console.WriteLine("Unable to convert '{0}' to a Decimal.", line);
                }
                catch (OverflowException)
                {
                    newWeather.Temp = null;
                    //Console.WriteLine("'{0}' is outside the range of a Decimal.", line);
                }
                newWeather.Luftfuktighet = int.Parse(entries[3]);
                weatherList.Add(newWeather);
            }

            foreach (var x in weatherList) //Lägger till info i Databasen
            {
                context.WeatherTable.Add(x); //Koppling till DbSet Weather
            }
            context.SaveChanges(); // Sparar

            ////////// Initiliaze new info in "Average Info List" /////////////////
            
            List<AvgWeather> avgWeatherList = new List<AvgWeather>();

            List<decimal?> avgdagtempUte, avgdagtempInne;
            List<int> avgluftUte, avgluftInne;
            

            decimal? dagstempUte, dagstempInne;
            int luftfuktInne = 0, luftfuktUte = 0;
            string mogelriskInne = "", mogelriskUte = "";

            int i=1, j=10; // Första dagen är 10 Oktober
            for (i = 1; i < 200; i++)
            {

                if (j == 11 && i == 31) //När det blir sista November +1 avslutar den loopen (Finns ingen 31 November)
                {
                    break;
                }

                if (j == 10 && i == 32) //(Finns ingen 32 Oktober)
                {
                    i = 1; // Första
                    j = 11; // November
                }

                DateTime dag = new DateTime(2016, j, i);
                
                if (weatherList.
                     Where(x => x.Tid.Day == i).
                     Where(x => x.Tid.Month == j).
                     Select(x => x.Temp).Any() 
                     &&
                     weatherList.
                     Where(x => x.Tid.Day == i).
                     Where(x => x.Tid.Month == j).
                     Select(x => x.Luftfuktighet).Any()) //Om det finns temperatur och luftfuktighet värde så körs if-satsen
                {


                    //Medeltemperatur Ute
                    avgdagtempUte = weatherList.
                         Where(x => x.Tid.Day == i).
                         Where(x => x.Tid.Month == j).
                         Where(x => x.Plats == "Ute").
                         Select(x => x.Temp).ToList();

                    var count = avgdagtempUte.Count();
                    avgdagtempUte.RemoveAll(item => item == null);

                    count = avgdagtempUte.Count();
                    var sum = avgdagtempUte.Sum();
                    var avgtemp = sum / count;

                    dagstempUte = avgtemp;
                    //dagstempUte = avgdagtempUte.Average();


                    //Medeltemperatur Inne
                    avgdagtempInne = weatherList.
                         Where(x => x.Tid.Day == i).
                         Where(x => x.Tid.Month == j).
                         Where(x => x.Plats == "Inne").
                         Select(x => x.Temp).ToList();
                    avgdagtempInne.RemoveAll(item => item == null);

                    var count2 = avgdagtempInne.Count();
                    var sum2 = avgdagtempInne.Sum();
                    var avgtemp2 = sum2 / count2;
                    dagstempInne = avgtemp2;
                    //dagstempInne = avgdagtempInne.Average();

                    //Medelfuktighet Ute
                    avgluftUte = weatherList.
                          Where(x => x.Tid.Day == i).
                          Where(x => x.Tid.Month == j).
                          Where(x => x.Plats == "Ute").
                          Select(x => x.Luftfuktighet).ToList();
                    luftfuktUte = Convert.ToInt32(avgluftUte.Average());

                    //Medelfuktighet Inne
                    avgluftInne = weatherList.
                       Where(x => x.Tid.Day == i).
                       Where(x => x.Tid.Month == j).
                       Where(x => x.Plats == "Inne").
                       Select(x => x.Luftfuktighet).ToList();
                    luftfuktInne = Convert.ToInt32(avgluftInne.Average());

                    //Mögelrisk Inne
                    if ((dagstempInne >= 30) && (dagstempInne <= 50) && (luftfuktInne >= 90) && (luftfuktInne <= 100))
                    { mogelriskInne = "Hög risk"; }
                    if (dagstempInne >= 15 && dagstempInne <= 50 && luftfuktInne >= 80 && luftfuktInne <= 100)
                    { mogelriskInne = "Låg risk"; }
                    else
                    { mogelriskInne = "Ingen risk"; }

                    //Mögelrisk Ute
                    if ((dagstempUte >= 30) && (dagstempUte <= 50) && (luftfuktUte >= 90) && (luftfuktUte <= 100))
                    { mogelriskUte = "Hög risk"; }
                    else if (dagstempUte >= 8 && dagstempUte <= 50 && luftfuktUte >= 80 && luftfuktUte <= 100)
                    { mogelriskUte = "Låg risk"; }
                    else
                    { mogelriskUte = "Ingen risk"; }


                    var medeldagenute = new AvgWeather { Datum = dag, Plats = "Ute", MedelTemp = dagstempUte, MedelLuftfuktighet = luftfuktUte, Mogelrisk = mogelriskUte };
                    var medeldageninne = new AvgWeather { Datum = dag, Plats = "Inne", MedelTemp = dagstempInne, MedelLuftfuktighet = luftfuktInne, Mogelrisk = mogelriskInne };

                    context.AvgWeatherTable.Add(medeldagenute); //Koppling till DbSet Weather
                    context.AvgWeatherTable.Add(medeldageninne); //Koppling till DbSet Weather

                    context.SaveChanges(); //sparar

                }
            }
        }
    }
}
