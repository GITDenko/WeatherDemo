﻿SELECT * FROM WeatherTable 
WHERE Plats = 'Ute' AND Temp NOT BETWEEN (-1001) AND (-999)
ORDER BY Temp DESC;