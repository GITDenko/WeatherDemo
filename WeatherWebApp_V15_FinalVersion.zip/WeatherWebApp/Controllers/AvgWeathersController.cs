﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WeatherWebApp.Models;

namespace WeatherWebApp.Controllers
{
    public class AvgWeathersController : Controller
    {
        private readonly WeatherContext _context;

        public AvgWeathersController(WeatherContext context)
        {
            _context = context;
        }

        // GET: AvgWeathers
        public ViewResult Index(string sortOrder, string searchString)
        {
            // Kopplingar till AvgWeather Index (och switch case)
            // ViewBag som mellansteg för att spara information innan den visas på sidan.

            ViewBag.CurrentSort = sortOrder;
            ViewBag.Date = String.IsNullOrEmpty(sortOrder) ? "date" : "";
            ViewBag.Place = String.IsNullOrEmpty(sortOrder) ? "plats" : ""; //Plats
            ViewBag.Temperature = String.IsNullOrEmpty(sortOrder) ? "temperatur" : ""; //Medeltemp, högst till lägst
            ViewBag.Humidity = String.IsNullOrEmpty(sortOrder) ? "luftfukt" : ""; //Luftfukt., lägst till högst
            ViewBag.MoldRisk = String.IsNullOrEmpty(sortOrder) ? "mogelrisk" : ""; //Mögelrisk, lägst till högst

            ViewBag.Fall = String.IsNullOrEmpty(sortOrder) ? "höst" : ""; //Meteorlogisk Höst
            ViewBag.Winter = String.IsNullOrEmpty(sortOrder) ? "vinter" : ""; //Meteorlogisk Vinter

            // Hämtar all info från listan som har lagrat medelvärden
            var weather = from w in _context.AvgWeatherTable select w;

            if (!String.IsNullOrEmpty(searchString)) //SÖKFUNKTION
            {
                //Söker efter datum först, går det inte så söker den via *string* plats istället. 
                //(== Fungerar som fel validering)
                try
                {
                    DateTime.Parse(searchString);
                    weather = weather.Where(w => w.Datum == DateTime.Parse(searchString));
                }
                catch (FormatException)
                {
                    weather = weather.Where(w => w.Plats == searchString);
                }
            } 

            // Beronde på vilket switch case som väljs så sorteras listan på det önskade sättet
            // med ett lambda uttryck
            switch (sortOrder)
            {
                case "date":
                    weather = weather.OrderBy(w => w.Datum);
                    break;
                case "plats":
                    weather = weather.OrderBy(w => w.Plats == "Inne");
                    break;
                case "temperatur":
                    weather = weather.OrderByDescending(w => w.MedelTemp);
                    break;
                case "luftfukt":
                    weather = weather.OrderBy(w => w.MedelLuftfuktighet);
                    break;
                case "mogelrisk":
                    weather = weather.OrderByDescending(x => x.Mogelrisk == "Ingen risk");
                    break;

                case "höst":
                    var tempList = weather.Where(x => x.Plats == "Ute").Select(x => x.MedelTemp).ToList();
                    int i = tempList.FindIndex(tempvalue => tempvalue < 10);
                    int maxindex = tempList.Count();
                    foreach (var temp in tempList)
                    {
                        if (i + 5 == maxindex) // Felhantering så att den inte kommer över listans index
                        {
                            weather = weather.Where(x => x.MedelTemp == null);
                            break;
                        }

                        //Söker efter temperatur mellan 0 till 10, fem dagar i rad via index
                        if (tempList[i] >= 0 && tempList[i] <= 10 &&
                            tempList[i + 1] >= 0 && tempList[i + 1] <= 10 &&
                            tempList[i + 2] >= 0 && tempList[i + 2] <= 10 &&
                            tempList[i + 3] >= 0 && tempList[i + 3] <= 10 &&
                            tempList[i + 4] >= 0 && tempList[i + 4] <= 10)
                        {
                            weather = weather.Where(x => x.MedelTemp == tempList[i]);
                            break;
                        }
                        i++;
                    }
                    break;

                case "vinter":
                    tempList = weather.Where(x => x.Plats == "Ute").Select(x => x.MedelTemp).ToList();
                    i = tempList.FindIndex(tempvalue => tempvalue <= 0);
                    maxindex = tempList.Count();
                    foreach (var temp in tempList)
                    {
                        if (i+5==maxindex)  // Felhantering så att den inte kommer över listans index
                        {
                            weather = weather.Where(x => x.MedelTemp == null);
                            break;
                        }

                        //Söker efter temperatur mellan 0 till 10, fem dagar i rad via index
                        if (tempList[i] >= 0 && tempList[i] <= 0 &&
                            tempList[i + 1] >= 0 && tempList[i + 1] <= 0 &&
                            tempList[i + 2] >= 0 && tempList[i + 2] <= 0 &&
                            tempList[i + 3] >= 0 && tempList[i + 3] <= 0 &&
                            tempList[i + 4] >= 0 && tempList[i + 4] <= 0)
                        {
                            weather = weather.Where(x => x.MedelTemp == tempList[i]);
                            break;
                        }
                        i++;
                    }
                    break;
            }
            return View(weather.ToList());
        }

        // GET: AvgWeathers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var avgWeather = await _context.AvgWeatherTable
                .FirstOrDefaultAsync(m => m.Id == id);
            if (avgWeather == null)
            {
                return NotFound();
            }

            return View(avgWeather);
        }

        // GET: AvgWeathers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: AvgWeathers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Datum,Plats,MedelTemp,MedelLuftfuktighet,Mogelrisk")] AvgWeather avgWeather)
        {
            if (ModelState.IsValid)
            {
                _context.Add(avgWeather);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(avgWeather);
        }

        // GET: AvgWeathers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var avgWeather = await _context.AvgWeatherTable.FindAsync(id);
            if (avgWeather == null)
            {
                return NotFound();
            }
            return View(avgWeather);
        }

        // POST: AvgWeathers/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Datum,Plats,MedelTemp,MedelLuftfuktighet,Mogelrisk")] AvgWeather avgWeather)
        {
            if (id != avgWeather.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(avgWeather);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AvgWeatherExists(avgWeather.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(avgWeather);
        }

        // GET: AvgWeathers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var avgWeather = await _context.AvgWeatherTable
                .FirstOrDefaultAsync(m => m.Id == id);
            if (avgWeather == null)
            {
                return NotFound();
            }

            return View(avgWeather);
        }

        // POST: AvgWeathers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var avgWeather = await _context.AvgWeatherTable.FindAsync(id);
            _context.AvgWeatherTable.Remove(avgWeather);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AvgWeatherExists(int id)
        {
            return _context.AvgWeatherTable.Any(e => e.Id == id);
        }
    }
}
