﻿SELECT * FROM WeatherTable 
WHERE Plats = 'Inne' AND Luffuktighet >= 90 AND Temp BETWEEN 20 AND 50 AND Temp NOT BETWEEN (-1001) AND (-999);