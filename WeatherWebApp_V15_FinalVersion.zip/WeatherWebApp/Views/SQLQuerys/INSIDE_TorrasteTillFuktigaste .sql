﻿SELECT * FROM WeatherTable 
WHERE Plats = 'Inne' AND Temp NOT BETWEEN (-1001) AND (-999)
ORDER BY Luffuktighet DESC;