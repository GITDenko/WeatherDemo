﻿SELECT AVG (Temp) FROM WeatherTable
WHERE Temp NOT BETWEEN (-999) AND (-1001)
AND (DATEPART(yy, Tid) = 2016 
AND DATEPART (mm, Tid) = 11
AND DATEPART (dd, Tid) = 01)
AND Plats = 'Ute'
ORDER BY Plats DESC;