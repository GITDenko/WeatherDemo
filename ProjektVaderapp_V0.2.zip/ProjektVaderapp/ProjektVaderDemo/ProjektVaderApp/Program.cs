﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace ProjektVaderApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"../../../../TempFuktData.csv";
            List<string> lines = File.ReadAllLines(filePath).ToList();
            
            List<WeatherApp> weatherDataList = new List<WeatherApp>();

            int i = 0;
            foreach (string line in lines)
            {
                CultureInfo provider = CultureInfo.InvariantCulture;

                string[] entries = line.Split(',');
                WeatherApp newWeather = new WeatherApp();
                
                newWeather.Id = i; i++; //Kanske tar bort i++;
                newWeather.Tid = DateTime.Parse(entries[0]);
                newWeather.Plats = entries[1];

                try
                {
                    newWeather.Temp = decimal.Parse(entries[2], provider);
                    //Console.WriteLine("Converted '{0}' to {1}.", line, newWeather.Temp);
                }
                catch (FormatException)
                {
                    //Console.WriteLine("Unable to convert '{0}' to a Decimal.", line);
                }
                catch (OverflowException)
                {
                    //Console.WriteLine("'{0}' is outside the range of a Decimal.", line);
                }

                newWeather.Luffuktighet = int.Parse(entries[3]);
                weatherDataList.Add(newWeather);
                
            }

            foreach (var weather in weatherDataList)
            {
                Console.WriteLine($"{ weather.Id } { weather.Tid } { weather.Plats } { weather.Temp } { weather.Luffuktighet }");
            }

        }
    }
}
