﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjektVaderApp
{
    public class WeatherApp
    {
        public int Id { get; set; }
        public DateTime Tid { get; set; }
        public string Plats { get; set; }
        public decimal Temp { get; set; }
        public int Luffuktighet { get; set; }

    }
}
