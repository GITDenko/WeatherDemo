﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WeatherWebApplication.Models
{
    public class Weather
    {
        public int Id { get; set; }
        public DateTime Tid { get; set; }
        public string Plats { get; set; }
        public decimal Temp { get; set; }
        public int Luffuktighet { get; set; }
    }
}
