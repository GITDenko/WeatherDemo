﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WeatherWebApp.Models;

namespace WeatherWebApp.Data
{
    public class DbInitializer
    {
        public static void Initialize(WeatherContext context)
        {
            context.Database.EnsureCreated();

            if (context.WeatherTable.Any())
            {
                return;
            }

            string filePath = @"TempFuktData.csv";

            List<string> lines = File.ReadAllLines(filePath).ToList();

            List<Weather> weatherList = new List<Weather>();

            foreach (string line in lines)
            {
                CultureInfo provider = CultureInfo.InvariantCulture;

                string[] entries = line.Split(',');
                Weather newWeather = new Weather();

                newWeather.Tid = DateTime.Parse(entries[0]); 
                newWeather.Plats = entries[1];
                try
                {
                    newWeather.Temp = decimal.Parse(entries[2], provider);
                    //Console.WriteLine("Converted '{0}' to {1}.", line, newWeather.Temp);
                }
                catch (FormatException)
                {
                    newWeather.Temp = -1000;
                    //Console.WriteLine("Unable to convert '{0}' to a Decimal.", line);
                }
                catch (OverflowException)
                {
                    newWeather.Temp = -1000;
                    //Console.WriteLine("'{0}' is outside the range of a Decimal.", line);
                }
                newWeather.Luffuktighet = int.Parse(entries[3]);
                weatherList.Add(newWeather);
            }

            foreach (var x in weatherList) //Lägger till info i Databasen
            {
                context.WeatherTable.Add(x); //Koppling till DbSet Weather
            }
            context.SaveChanges(); // Sparar
        }
    }
}
