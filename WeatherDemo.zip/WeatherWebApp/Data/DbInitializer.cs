﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WeatherWebApp.Models;

namespace WeatherWebApp.Data
{
    public class DbInitializer
    {
        public static void Initialize(WeatherContext context)
        {
            context.Database.EnsureCreated();

            if (context.WeatherTable.Any())
            {
                return;
            }

            var inneVäder = new Weather
            {
                Tid = DateTime.Now,
                Plats = "Inne",
                Temp = 20.34m,
                Luffuktighet = 10
            };

            var uteVäder = new Weather
            {
                Tid = DateTime.Now,
                Plats = "Ute",
                Temp = 10.34m,
                Luffuktighet = 60
            };

            var weather = new Weather[]
            {
                inneVäder,
                uteVäder
            };

            foreach (var x in weather) //Lägger till info i Databasen
            {
                context.WeatherTable.Add(x);
            }
            context.SaveChanges(); // Sparar
        }
    }
}
